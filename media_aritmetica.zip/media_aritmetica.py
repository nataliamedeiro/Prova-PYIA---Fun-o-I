
def media(n1, n2, n3):
    resultado = (n1 + n2 + n3) / 3
    return resultado

print(media(8, 13, 19))  
